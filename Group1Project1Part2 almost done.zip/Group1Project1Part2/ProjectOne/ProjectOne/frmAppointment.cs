﻿//AUTHOR:    Zach Davis, Sabrina Ahmed, Pete Lange, Christian Toy
//COURSE:    ISTM 250.503
//FORM:      frmAppointment.cs
//PURPOSE:   For AllPets Veternary Clinic to record appointments and process fees. 
//INPUT:     Personal information, Billing, Pet information, services, and appointment
//PROCESS:   Take in all inputs to calculate cost and make appointment
//OUTPUT:    Show form process and cost of services 
//TERMINATE: Click the close button or press the esc key
//HONOR CODE:"On my honor, as an Aggie, I have neither given nor recieved
//           unauthorized aid on this academic work."
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectOne
{
    public partial class frmAppointment : Form
    {
        public frmAppointment()
        {
            InitializeComponent();
        }

        //Lists, Arrays, and variables that needed more scope
        List<string> Customers = new List<string>();
        List<string> CustomersFullInfo = new List<string>();
        List<string> FullServices = new List<string>() { "Check-up/Maintenance", "Medical attention", "Pre-operative", "Post-operative", "Dental cleaning", "Grooming" };
        string[] strInventoryLost = new string[6] { "0", "1", "2", "3", "4", "5" };
        string[] FullServicesAmountArray = new string[6] { "$30.00", "$50.00", "$25.00", "$15.00", "$120.00", "$55.00" };
        string[] InfoArray = new string[5];
        int intCost;

        private void btnClearPersonal_Click_1(object sender, EventArgs e)
        {
            //Clears all the personal data
            txtAddress.Text = "";
            txtCity.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtZip.Text = "";
        }

        private void GoToBilling()
        {
            //Method to go to the Billing GroupBox from the Personal Info GroupBox
            grpBillingAddress.Location = new Point(12, 12);
            grpBillingAddress.Visible = true;
            txtBillingZip.Visible = true;
            txtBillingCity.Visible = true;
            txtBillingAddress.Visible = true;
            lblBillingAddress.Visible = true;
            lblBillingCity.Visible = true;
            lblBillingZip.Visible = true;
            chkAddress.Visible = true;
            btnBillingAddressClear.Visible = true;
            btnBillingAddressSave.Visible = true;
            txtBillingAddress.Text = InfoArray[1];
            txtBillingCity.Text = InfoArray[2];
            txtBillingZip.Text = InfoArray[3];
        }

        private void btnSavePersonal_Click(object sender, EventArgs e)
        {
            //saves all the user personal information into an array
            //if (IsValidPersonal())
            {
                InfoArray[0] = txtName.Text;
                InfoArray[1] = txtAddress.Text;
                InfoArray[2] = txtCity.Text;
                InfoArray[3] = txtZip.Text;
                InfoArray[4] = txtPhone.Text;
                Customers.Add(txtName.Text);
                string totalsString = "";
                for (int i = 0; i < (InfoArray.Length); i++)
                {
                    if ((i + 1) == InfoArray.Length)
                    {
                        totalsString += InfoArray[i];
                    }
                    else
                    {
                        totalsString += InfoArray[i] + ", ";
                    }
                    //saves the information into a list in case they wanted to
                    //add more information later on
                    CustomersFullInfo.Add(totalsString);
                    grpPersonalInfo.Visible = false;
                    //goes the the Billing GroupBox
                    GoToBilling();
                }

            }

        }

        private void chkAddress_CheckedChanged(object sender, EventArgs e)
        {
            //activates if the user has a different Billing Address
            txtBillingAddress.Enabled = true;
            txtBillingCity.Enabled = true;
            txtBillingZip.Enabled = true;
            txtBillingAddress.Focus();
        }

        private void txtBillingAddress_Leave(object sender, EventArgs e)
        {
            //highlights the Billing City TextBox when tabed into
            txtBillingCity.Focus();
        }

        private void txtBillingCity_Leave(object sender, EventArgs e)
        {
            //highlights the Billing Zip Code TextBox when tabed into
            txtBillingZip.Focus();
        }

        private void btnBillingAddressClear_Click(object sender, EventArgs e)
        {
            //clears the Billing Address GroupBox
            txtBillingAddress.Text = "";
            txtBillingCity.Text = "";
            txtBillingZip.Text = "";
        }

        private void btnBillingAddressSave_Click(object sender, EventArgs e)
        {
            //if (IsValidBilling())
            {
                //Goes from Billing Address the Specifics
                string strAdding = "";
                string[] BillingInfoArray = new string[3];
                BillingInfoArray[0] = txtBillingAddress.Text;
                BillingInfoArray[1] = txtBillingCity.Text;
                BillingInfoArray[2] = txtBillingZip.Text;
                //saves all of the customers information in a List
                if (BillingInfoArray[0] != InfoArray[1])
                {
                    for (int i = 0; i < (BillingInfoArray.Length); i++)
                    {
                        if ((i + 1) == BillingInfoArray.Length)
                        {
                            strAdding += BillingInfoArray[i];
                        }
                        else
                        {
                            strAdding += BillingInfoArray[i] + ", ";
                        }
                    }
                    CustomersFullInfo.Add(strAdding);
                }
                else
                {
                    CustomersFullInfo.Add("Billing same as physical");
                }
                grpBillingAddress.Visible = false;
                grpSpecifics.Location = new Point(12, 12);
                grpSpecifics.Visible = true;

            }

        }

        private void btnPetClear_Click(object sender, EventArgs e)
        {
            //clears the info in specifics
            txtPetName.Text = "";
            cboSpecies.Text = "";
        }

        private void btnBillingBack_Click(object sender, EventArgs e)
        {
            //goes from the Billing Address GroupBox to the Personal Info GroupBox
            grpBillingAddress.Visible = false;
            grpPersonalInfo.Visible = true;
        }

        private void btnPetBack_Click(object sender, EventArgs e)
        {
            //goes from the Specifics GroupBox to the Billing Address Groupbox
            grpSpecifics.Visible = false;
            grpBillingAddress.Visible = true;
        }

        string strType = null;
        private void btnPetSave_Click(object sender, EventArgs e)
        {
            //if (IsValidPet())
            {
                //goes from specifics to services
                //makes the correct picture visible
                string strPetName = txtPetName.Text;
                strType = cboSpecies.Text;
                strType = strType.ToLower();
                grpSpecifics.Visible = false;
                if (strType == "dog")
                    picDog.Visible = true;
                if (strType == "cat")
                    picCat.Visible = true;
                if (strType == "bird")
                    picBird.Visible = true;
                if (strType == "snake")
                    picSnake.Visible = true;

                txtServiceName.Text = strPetName;
                txtServiceName.ReadOnly = true;
                grpService.Location = new Point(12, 12);
                grpService.Visible = true;


            }

        }

        private void btnServiceBack_Click(object sender, EventArgs e)
        {
            //Goes Back from the services page
            grpService.Visible = false;
            grpSpecifics.Visible = true;
            strType = cboSpecies.Text;
            strType = strType.ToLower();
            if (strType == "dog")
                picDog.Visible = false;
            if (strType == "cat")
                picCat.Visible = false;
            if (strType == "bird")
                picBird.Visible = false;
            if (strType == "snake")
                picSnake.Visible = false;
        }

        private void btnAddService_Click(object sender, EventArgs e)
        {
            //if (IsValidAdd())
            {
                //moves a value from the ComboBox to the Listbox
                //calculates the subtotal
                List<string> Services = new List<string>();
                String strCost;
                int intServiceTracker;
                string strServiceCount = "";
                string strCurrentService = cboService.Text;
                if (strCurrentService != "")
                    Services.Add(strCurrentService);
                //creates a subtotal for the values
                //Removes the service from the ComboBox
                for (int i = 0; i < (FullServices.Count); i++)
                {
                    if (FullServices[i] == Services[(Services.Count - 1)])
                    {
                        ServiceItems xx = new ServiceItems();
                        if (strInventoryLost[i] == "0")
                        {
                            xx.strCheckUpArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("0");
                        }
                        if (strInventoryLost[i] == "1")
                        {
                            xx.strMedicalAttArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("1");
                        }
                        if (strInventoryLost[i] == "2")
                        {
                            xx.strPreOpArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("2");
                        }
                        if (strInventoryLost[i] == "3")
                        {
                            xx.strPostOpArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("3");
                        }
                        if (strInventoryLost[i] == "4")
                        {
                            xx.strDentalCleanArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("4");
                        }
                        if (strInventoryLost[i] == "5")
                        {
                            xx.strGroomArray();
                            ServiceItems.Variables.StrWhichArrayList.Add("5");
                        }



                        string[,] strServiceItemsArray = new string[14, 7];
                        strServiceItemsArray = ServiceItemDB.ReadServiceItemsFile();
                        //UpdateInventoryArray(FullServices[i], strServiceItemsArray[,]);
                        strInventoryLost[i] ="1";
                        cboService.Items.RemoveAt(i);
                        Services.Add(FullServicesAmountArray[i]);
                        strCost = Convert.ToString(FullServicesAmountArray[i]);
                        strCost = strCost.Remove(0, 1);
                        if (FullServices[i] == "Dental Cleaning")
                        {
                            strCost = strCost.Remove(3, 3);
                        }
                        else
                        {
                            strCost = strCost.Remove(2, 3);
                        }
                        intCost += Convert.ToInt32(strCost);
                        txtSubtotal.Text = intCost.ToString("C");
                        FullServices.RemoveAt(i);
                    }
                }
                intServiceTracker = 0;
                //created to combine the services with their relative cost
                for (int i = 0; i < (Services.Count); i++)
                {
                    if ((i + 1) == Services.Count) //only does this once the input has already been assigned a value
                    {
                        strServiceCount += Services[i];
                        intServiceTracker = 1;
                    }
                    else
                    {
                        strServiceCount += Services[i] + ", ";
                    }
                    if (intServiceTracker == 1)
                        lstServices.Items.Add(strServiceCount);
                }
                cboService.Text = "";
            }
            
        }

        private void btnServiceSave_Click(object sender, EventArgs e)
        {
            //Takes the user to the appointment GroupBox
            //if (IsValidService())
            {
                grpService.Visible = false;
                decimal decSalesTax = Convert.ToDecimal(intCost) * .0825m;
                decimal decTotalCost = decSalesTax + Convert.ToDecimal(intCost);
                txtAppointmentCost.Text = intCost.ToString("C");
                txtSalesTax.Text = decSalesTax.ToString("C");
                txtTotalCost.Text = decTotalCost.ToString("C");
                grpAppointment.Location = new Point(12, 12);
                grpAppointment.Visible = true;
                mocDate.MinDate = DateTime.Today;
            }

        }

        private void btnServiceClear_Click(object sender, EventArgs e)
        {
            //Clears the input in the services groupbox
            cboService.Text = "";
            lstServices.Items.Clear();
            intCost = 0;
            txtSubtotal.Text = "";
            List<string> FullServices = new List<string>() { "Check-up/Maintenance", "Medical attention", "Pre-operative", "Post-operative", "Dental cleaning", "Grooming" };
            string[] FullServicesArray = new String[6] { "Check-up/Maintenance", "Medical attention", "Pre-operative", "Post-operative", "Dental cleaning", "Grooming" };
            cboService.Items.Clear();
            cboService.Items.AddRange(FullServicesArray);
        }

        private void btnAppointmentBack_Click(object sender, EventArgs e)
        {
            //returns the user to the Services GroupBox
            grpAppointment.Visible = false;
            grpService.Visible = true;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //if (IsValidAppointment())
            {
                //Takes the user from the first screen in the final Groupbox,
                //to the second screen of the final GroupBox.
                mocDate.Visible = false;
                lblTime.Visible = false;
                cboTime.Visible = false;
                btnConfirm.Visible = false;
                btnAppointmentBack.Visible = false;
                btnAppointmentBack.Enabled = false;
                btnAppointmentBack2.Visible = true;
                btnAppointmentBack2.Enabled = true;
                btnAppointmentRestart.Visible = true;
                btnAppointmentRestart.Enabled = true;
                btnCreateAnother.Enabled = true;
                btnCreateAnother.Visible = true;
                txtAppointmentCost.Visible = false;
                txtSalesTax.Visible = false;
                txtTotalCost.Visible = false;
                lblSalesTax.Visible = false;
                lblTotalCost.Visible = false;
                lblCost.Visible = false;
                lblEnding.Visible = true;
                lblComments.Visible = true;
                txtComments.Visible = true;
                btnInventory.Visible = true;
                
            }
        }

        private void btnCreateAnother_Click(object sender, EventArgs e)
        {
            StartOver();
        }

        private void btnAppointmentRestart_Click(object sender, EventArgs e)
        {
            StartOver();
        }

        private void StartOver()
        {
            //This is a method because regardless of if the individual wanted to make a new appointment, 
            //or wanted to start over, everything needs to be cleared.
            cboTime.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
            txtZip.Text = "";
            txtPetName.Text = "";
            cboSpecies.Text = "";
            cboService.Text = "";
            lstServices.Items.Clear();
            intCost = 0;
            txtSubtotal.Text = "";
            txtTotalCost.Text = "";
            txtSalesTax.Text = "";
            txtAppointmentCost.Text = "";
            txtServiceName.Text = "";
            grpAppointment.Visible = false;
            grpPersonalInfo.Visible = true;
            chkAddress.Checked = false;
            lblEnding.Visible = true;
            List<string> FullServices = new List<string>() { "Check-up/Maintenance", "Medical attention", "Pre-operative", "Post-operative", "Dental cleaning", "Grooming" };
            string[] FullServicesArray = new String[6] { "Check-up/Maintenance", "Medical attention", "Pre-operative", "Post-operative", "Dental cleaning", "Grooming" };
            cboService.Items.Clear();
            cboService.Items.AddRange(FullServicesArray);
            cboTime.Text = "";
        }

        private void btnAppointmentBack2_Click(object sender, EventArgs e)
        {
            //The final GroupBox has two screens, this is to go from the second to the first screen.
            mocDate.Visible = true;
            btnInventory.Visible = false;
            txtComments.Visible = false;
            lblComments.Visible = false;
            btnConfirm.Visible = true;
            btnAppointmentBack.Visible = false;
            btnAppointmentBack.Enabled = true;
            btnAppointmentBack2.Visible = false;
            btnAppointmentBack2.Enabled = false;
            btnAppointmentRestart.Visible = false;
            btnAppointmentRestart.Enabled = false;
            btnCreateAnother.Enabled = false;
            btnCreateAnother.Visible = false;
            btnAppointmentBack.Visible = true;
            lblEnding.Visible = false;
            txtAppointmentCost.Visible = true;
            txtSalesTax.Visible = true;
            txtTotalCost.Visible = true;
            lblSalesTax.Visible = true;
            lblTotalCost.Visible = true;
            lblCost.Visible = true;
            lblTime.Visible = true;
            cboTime.Visible = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //always visible, closes the program
            this.Close();
        }

        //DATA VALIDATION
        //makes sure personal information are valid entries
        public bool IsValidPersonal()
        {
            return 
                IsPresent(txtName, "Name") &&
                IsPresent(txtAddress, "Address") &&
                IsPresent(txtCity, "City") &&
                IsPresent(txtZip, "Zip") &&
                IsPresent(txtPhone, "Phone") &&

                IsString(txtName, "Name") &&
                IsString(txtAddress, "Address") &&
                IsString(txtCity, "City") &&

                IsInt32Zip(txtZip, "Zip") &&
                IsDecimalPhone(txtPhone, "Phone") &&

                IsLengthZip(txtZip, "Zip") &&
                IsLengthPhone(txtPhone, "Phone") &&

                IsWithinRangeCity(txtCity, "City");


        }
        //makes sure billing information are valid entries
        public bool IsValidBilling()
        {
            return
                IsPresent(txtBillingAddress, "Billing Address") &&
                IsPresent(txtBillingCity, "Billing City") &&
                IsPresent(txtBillingZip, "Billing Zip") &&

                IsString(txtAddress, "Billing Address") &&
                IsString(txtBillingCity, "Billing City") &&

                IsInt32Zip(txtBillingZip, "Billing Zip") &&

                IsLengthZip(txtBillingZip, "Billing Zip");

        }
        //makes sure pet name and species are valid entries
        public bool IsValidPet()
        {
            return
                IsPresent(txtPetName, "Pet Name") &&
                IsPresentCombo(cboSpecies, "Species") &&
                IsString(txtPetName, "Pet Name") &&
                IsWithinRangeCombo(cboSpecies, "Species");


        }
        //makes sure service subtotal is a valid entry
        public bool IsValidService()
        {
            return
                IsZero(txtSubtotal, "You must add a service to make an appointment.");
        }

        public bool IsValidAdd()
        {
            return
                IsPresentCombo(cboService, "Service");
        }
        //makes sure appointment time is a valid entry
        public bool IsValidAppointment()
        {
            return
                IsZeroCombo(cboTime, "You must pick an appointment time.");
        }
        //checks if value is present
        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;

        }
        //checks is species is put in
        public bool IsPresentCombo(ComboBox comboBox, string name)
        {
            if (comboBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry Error");
                comboBox.Focus();
                return false;
            }
            return true;

        }
        //checks if zip code is only integer
        public bool IsInt32Zip(TextBox textBox, string name)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer value.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }
        //checks if phone number is acceptable
        public bool IsDecimalPhone(TextBox textBox, string name)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer value.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }
        //checks if name, address, and city are acceptable
        public bool IsString(TextBox textBox, string name)
        {
            decimal number = 0m;
            if (Decimal.TryParse(textBox.Text, out number))
            {
                MessageBox.Show(name + " must be an string value.", "Entry Error");
                textBox.Focus();
                return false;
            }
            else
            {
                return true;
            }
        }
        //checks if zip code is correct length
        public bool IsLengthZip(TextBox textBox, string name)
        {
            string strnumber = textBox.Text;
            if (strnumber.Length != 5)
            {
                MessageBox.Show(name + " must be 5 integers long. (Ex. 77401)", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
        //checks if phone number is correct length
        public bool IsLengthPhone(TextBox textBox, string name)
        {
            string strnumber = textBox.Text;
            if (strnumber.Length != 10)
            {
                MessageBox.Show(name + " must be 10 integers long. (Ex. 2813453340)", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }
        //checks if species is accepted
        public bool IsWithinRangeCombo(ComboBox comboBox, string name)
        {
            string type = comboBox.Text;
            type = type.ToLower();
            if (type == "cat" || type == "dog" || type == "snake" || type == "bird")
                return true;
            else
            {
                MessageBox.Show("Species can only be Cat, Dog, Snake, or Bird.");
                return false;
            }

        }
        //checks if service was added
        public bool IsZero(TextBox textBox, string message)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(message);
                return false;
            }
            return true;
        }

        //Checks if pet species is empty
        public bool IsZeroCombo(ComboBox comboBox, string message)
        {
            if (comboBox.Text == "")
            {
                MessageBox.Show(message);
                return false;
            }
            return true;
        }

        //make sure only customers are from the college station/bryan area
        public bool IsWithinRangeCity(TextBox textBox, string name)
        {
            string strCity = textBox.Text;
            string strTrim = strCity.Replace(" ", String.Empty);
            //make all lowercase
            string strLower = strTrim.ToLower();

            if (strLower == "collegestation" || strLower == "bryan")
            {
                return true;
            }
            else
            {
                MessageBox.Show("Can only serve if city is College Station or Bryan.");
                return false;
            }
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            frmInventory frmInventory = new frmInventory();
            Inventory.Variables.StrEndInventory = frmInventory.UpdateInventoryArray();
            frmInventory.ShowDialog();
            //frmInventory.ReadFile();
            this.Close();
        }
    }
}
