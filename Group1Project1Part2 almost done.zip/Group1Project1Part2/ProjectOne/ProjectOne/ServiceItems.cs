﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProjectOne
{
    public struct ServiceItems
    {
        public class Variables
        {
            private static int intCounter = 0;
            public static int IntCounter
            {
                get { return intCounter; }
                set { intCounter = value; }
            }

            private static string[,] strHelper = null;
            public static string[,] StrHelper
            {
                get { return ServiceItemDB.ReadServiceItemsFile(); }
                set { strHelper = value; }
            }

            private static string[,] strCheckUpArray = new string[14, 2];
            public static string[,] StrCheckUpArray
            {
                get { return strCheckUpArray; }
                set { strCheckUpArray = value; }
            }

            private static string[,] strMedicalAttArray = new string[14, 2];
            public static string[,] StrMedicalAttArray
            {
                get { return strMedicalAttArray; }
                set { strMedicalAttArray = value; }
            }

            private static string[,] strPreOpArray = new string[14, 2];
            public static string[,] StrPreOpArray
            {
                get { return strPreOpArray; }
                set {strPreOpArray  = value; }
            }

            private static string[,] strPostOpArray = new string[14, 2];
            public static string[,] StrPostOpArray
            {
                get { return strPostOpArray; }
                set { strPostOpArray = value; }
            }

            private static string[,] strDentalCleanArray = new string[14, 2];
            public static string[,] StrDentalCleanArray
            {
                get { return strDentalCleanArray; }
                set { strDentalCleanArray = value; }
            }

            private static string[,] strGroomArray = new string[14, 2];
            public static string[,] StrGroomArray
            {
                get { return strGroomArray; }
                set { strGroomArray = value; }
            }

            private static List<string> strWhichArrayList = new List<string> ();
            public static List<string> StrWhichArrayList
            {
                get { return strWhichArrayList; }
                set { strWhichArrayList=value; }
            }

        }
        public void strCheckUpArray()
        {
            int nCol = 0;
            while (nCol < 14)
            {
                for (int i = 0; i <= 1; i++)
                {
                    Variables.StrCheckUpArray[nCol, i] = Variables.StrHelper[nCol, i];
                }
                nCol++;
            }
            Variables.IntCounter++;

        }

        public void strMedicalAttArray()
        {
            for (int i = 0; i <= 13; i++)
            {
                Variables.StrMedicalAttArray[i, 1] = Variables.StrHelper[i, 2];
            }

            for (int i = 0; i <= 13; i++)
            {
                Variables.StrMedicalAttArray[i, 0] = Variables.StrHelper[i, 0];
            }
            Variables.IntCounter++;
        }

        public void strPreOpArray()
        {
            for (int i = 0; i <= 13; i++)
            {
                Variables.StrPreOpArray[i, 1] = Variables.StrHelper[i, 3];
            }

            for (int i = 0; i <= 13; i++)
            {
                Variables.StrPreOpArray[i, 0] = Variables.StrHelper[i, 0];
            }
            Variables.IntCounter++;
        }
        public void strPostOpArray()
        {
            for (int i = 0; i <= 13; i++)
            {
                Variables.StrPostOpArray[i, 1] = Variables.StrHelper[i, 4];
            }

            for (int i = 0; i <= 13; i++)
            {
                Variables.StrPostOpArray[i, 0] = Variables.StrHelper[i, 0];
            }
            Variables.IntCounter++;
        }

        public void strDentalCleanArray()
        {
            for (int i = 0; i <= 13; i++)
            {
                Variables.StrDentalCleanArray[i, 1] = Variables.StrHelper[i, 5];
            }

            for (int i = 0; i <= 13; i++)
            {
                Variables.StrDentalCleanArray[i, 0] = Variables.StrHelper[i, 0];
            }
            Variables.IntCounter++;
        }
        public void strGroomArray()
        {
            for (int i = 0; i <= 13; i++)
            {
                Variables.StrGroomArray[i, 1] = Variables.StrHelper[i, 6];
            }

            for (int i = 0; i <= 13; i++)
            {
                Variables.StrGroomArray[i, 0] = Variables.StrHelper[i, 0];
            }
            Variables.IntCounter++;
        }
    }
}
