﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProjectOne
{
    public struct Inventory
    {
        public class Variables
        {
            private static string[,] strEndInventory;

            public static string[,] StrEndInventory
            {
                get { return strEndInventory; }
                set { strEndInventory = value; }
            }
        }


    }
}
