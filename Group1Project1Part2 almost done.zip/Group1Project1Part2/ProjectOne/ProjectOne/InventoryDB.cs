﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProjectOne
{
    class InventoryDB
    {
        // Declaration of constants for the Inventory and Ingredients text files paths
        private const string path = @"..\..\Inventory.txt";

        public static void UpdateInventoryFile(string[,] strInventoryArray)
        {
            StreamWriter textOut =
                new StreamWriter(
                    new FileStream(path, FileMode.Create, FileAccess.Write));

            for (int i = 0; i < strInventoryArray.GetLength(0); i++)
            {
                textOut.Write(strInventoryArray[i, 0] + "\t");
                textOut.Write(strInventoryArray[i, 1] + Environment.NewLine);
            }
            textOut.Close();
        }

        public static string[,] ReadInventoryFile()
        {

            StreamReader textIn = new StreamReader(new FileStream(path, FileMode.OpenOrCreate, FileAccess.Read));

            string[,] strInventoryArray = new string[14, 2];

            string line = null;

            string list = null;

            int intRemover;

            using (StreamReader sr = new StreamReader(path))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    if (line.Contains("\t\t"))
                    {
                        intRemover = Convert.ToInt32(line.IndexOf("\t"));
                        line = line.Remove(intRemover, 1);
                    }
                    list += line + "\t";
                }
            }
            string[] strNewInventoryArray = list.Split('\t');

            int intCounter = 0;
            for (int i = 0; i < strInventoryArray.GetLength(0); i++)
            {
                strInventoryArray[i, 0] = strNewInventoryArray[intCounter];
                strInventoryArray[i, 1] = strNewInventoryArray[intCounter + 1];
                intCounter += 2;
            }

            textIn.Close();

            return strInventoryArray;
        }
    }
}
