﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectOne
{
    public partial class frmInventory : Form
    {
        public class Variables
        {
            private static string[,] strInventoryArray = null;
            public static string[,] StrInventoryArray
            {
                get { return InventoryDB.ReadInventoryFile(); }
                set { strInventoryArray = value; }
            }
        }
        public frmInventory()
        {
            InitializeComponent();
        }

        string[,] strInventoryArray = new string[14, 2];
        string[,] strServiceItemsArray = new string[14, 7];

        private void frmInventory_Load(object sender, EventArgs e)
        {
            strInventoryArray = Variables.StrInventoryArray;
            strServiceItemsArray = ServiceItemDB.ReadServiceItemsFile();
            //string totalsString = "";
            //for (int i = 0; i < strInventoryArray.GetLength(0); i++)
            //{
            //    totalsString += strServiceItemsArray[i, 0] + ", " + strServiceItemsArray[i, 1] + ", " + strServiceItemsArray[i, 2] + ", " + strServiceItemsArray[i, 3] + ", " + strServiceItemsArray[i, 4] + ", " + strServiceItemsArray[i, 5] + ", " + strServiceItemsArray[i, 6] + "\n";
            //}
            //MessageBox.Show(totalsString);
            FillInventoryListBox();
        }

        public string[,] UpdateInventoryArray()
        {
            string[,] strWorkingInventoryArray = Variables.StrInventoryArray;
            for(int j=0; j<ServiceItems.Variables.StrWhichArrayList.Count; j++)
            {
                for (int i = 0; i <=13; i++)
                {
                    int intServiceAmount = 0;

                    if (ServiceItems.Variables.StrWhichArrayList[j]=="0")
                    {
                        if (ServiceItems.Variables.StrCheckUpArray[i, 1] == "")
                            ServiceItems.Variables.StrCheckUpArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrCheckUpArray[i, 1]);
                    }
                    if (ServiceItems.Variables.StrWhichArrayList[j] == "1")
                    {
                        if (ServiceItems.Variables.StrMedicalAttArray[i, 1] == "")
                            ServiceItems.Variables.StrMedicalAttArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrMedicalAttArray[i, 1]);
                    }
                    if (ServiceItems.Variables.StrWhichArrayList[j] == "2")
                    {
                        if (ServiceItems.Variables.StrPreOpArray[i, 1] == "")
                            ServiceItems.Variables.StrPreOpArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrPreOpArray[i, 1]);
                    }
                    if (ServiceItems.Variables.StrWhichArrayList[j] == "3")
                    {
                        if (ServiceItems.Variables.StrPostOpArray[i, 1] == "")
                            ServiceItems.Variables.StrPostOpArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrPostOpArray[i, 1]);
                    }
                    if (ServiceItems.Variables.StrWhichArrayList[j] == "4")
                    {
                        if (ServiceItems.Variables.StrDentalCleanArray[i, 1] == "")
                            ServiceItems.Variables.StrDentalCleanArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrDentalCleanArray[i, 1]);
                    }
                    if (ServiceItems.Variables.StrWhichArrayList[j] == "5")
                    {
                        if (ServiceItems.Variables.StrGroomArray[i, 1] == "")
                            ServiceItems.Variables.StrGroomArray[i, 1] = Convert.ToString(0);
                        intServiceAmount = Convert.ToInt32(ServiceItems.Variables.StrGroomArray[i, 1]);
                    }
                    int intInvetoryAmount = Convert.ToInt32(Variables.StrInventoryArray[i, 1]);
                    int intSubtractHelp = intInvetoryAmount - intServiceAmount;
                    strWorkingInventoryArray[i, 1] = Convert.ToString(intSubtractHelp);
                }
            }

            ////if (ListedItemItem == "Grooming")
            //{
            //    for(int j = 0; j < strInventoryArray.GetLength(0); j++)
            //    {
            //        strInventoryArray[j, 1] = Convert.ToString(Convert.ToDecimal(strInventoryArray[j, 1]) - ListedQty * Convert.ToDecimal(strServiceItemsArray[j, 1]));
            //    }
            //}
            return strWorkingInventoryArray;
        }

        private void FillInventoryListBox()
        {
            lstInventory.Items.Clear();
            strInventoryArray = Inventory.Variables.StrEndInventory;
            string totalsString = "";
            for (int i = 0; i < strInventoryArray.GetLength(0); i++)
            {
                totalsString = strInventoryArray[i, 0] + ", " + strInventoryArray[i, 1];
                lstInventory.Items.Add(totalsString);
            }
        }

        private void lstInventory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
