﻿namespace ProjectOne
{
    partial class frmAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAppointment));
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblZip = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.btnSavePersonal = new System.Windows.Forms.Button();
            this.btnClearPersonal = new System.Windows.Forms.Button();
            this.chkAddress = new System.Windows.Forms.CheckBox();
            this.txtBillingAddress = new System.Windows.Forms.TextBox();
            this.txtBillingCity = new System.Windows.Forms.TextBox();
            this.txtBillingZip = new System.Windows.Forms.TextBox();
            this.lblBillingAddress = new System.Windows.Forms.Label();
            this.lblBillingCity = new System.Windows.Forms.Label();
            this.lblBillingZip = new System.Windows.Forms.Label();
            this.grpPersonalInfo = new System.Windows.Forms.GroupBox();
            this.grpBillingAddress = new System.Windows.Forms.GroupBox();
            this.btnBillingBack = new System.Windows.Forms.Button();
            this.btnBillingAddressClear = new System.Windows.Forms.Button();
            this.btnBillingAddressSave = new System.Windows.Forms.Button();
            this.grpSpecifics = new System.Windows.Forms.GroupBox();
            this.btnPetBack = new System.Windows.Forms.Button();
            this.cboSpecies = new System.Windows.Forms.ComboBox();
            this.txtPetName = new System.Windows.Forms.TextBox();
            this.lblPetName = new System.Windows.Forms.Label();
            this.lblPetSpecies = new System.Windows.Forms.Label();
            this.btnPetClear = new System.Windows.Forms.Button();
            this.btnPetSave = new System.Windows.Forms.Button();
            this.grpService = new System.Windows.Forms.GroupBox();
            this.lblServiceSubtotal = new System.Windows.Forms.Label();
            this.txtSubtotal = new System.Windows.Forms.TextBox();
            this.btnServiceSave = new System.Windows.Forms.Button();
            this.lstServices = new System.Windows.Forms.ListBox();
            this.cboService = new System.Windows.Forms.ComboBox();
            this.picSnake = new System.Windows.Forms.PictureBox();
            this.picBird = new System.Windows.Forms.PictureBox();
            this.picCat = new System.Windows.Forms.PictureBox();
            this.picDog = new System.Windows.Forms.PictureBox();
            this.btnServiceBack = new System.Windows.Forms.Button();
            this.txtServiceName = new System.Windows.Forms.TextBox();
            this.btnServiceClear = new System.Windows.Forms.Button();
            this.btnAddService = new System.Windows.Forms.Button();
            this.grpAppointment = new System.Windows.Forms.GroupBox();
            this.mocDate = new System.Windows.Forms.MonthCalendar();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.lblComments = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.cboTime = new System.Windows.Forms.ComboBox();
            this.lblEnding = new System.Windows.Forms.Label();
            this.btnAppointmentBack2 = new System.Windows.Forms.Button();
            this.btnCreateAnother = new System.Windows.Forms.Button();
            this.btnAppointmentRestart = new System.Windows.Forms.Button();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.txtTotalCost = new System.Windows.Forms.TextBox();
            this.txtSalesTax = new System.Windows.Forms.TextBox();
            this.btnAppointmentBack = new System.Windows.Forms.Button();
            this.txtAppointmentCost = new System.Windows.Forms.TextBox();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblSalesTax = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblProgrammers = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnInventory = new System.Windows.Forms.Button();
            this.grpPersonalInfo.SuspendLayout();
            this.grpBillingAddress.SuspendLayout();
            this.grpSpecifics.SuspendLayout();
            this.grpService.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSnake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDog)).BeginInit();
            this.grpAppointment.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(189, 48);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(534, 32);
            this.txtName.TabIndex = 0;
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(189, 90);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(534, 32);
            this.txtAddress.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(7, 51);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(186, 26);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Name (First Last):";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.Location = new System.Drawing.Point(87, 94);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(98, 26);
            this.lblAddress.TabIndex = 3;
            this.lblAddress.Text = "Address:";
            // 
            // txtCity
            // 
            this.txtCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCity.Location = new System.Drawing.Point(189, 132);
            this.txtCity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(534, 32);
            this.txtCity.TabIndex = 4;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(132, 136);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(56, 26);
            this.lblCity.TabIndex = 5;
            this.lblCity.Text = "City:";
            // 
            // lblZip
            // 
            this.lblZip.AutoSize = true;
            this.lblZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblZip.Location = new System.Drawing.Point(78, 179);
            this.lblZip.Name = "lblZip";
            this.lblZip.Size = new System.Drawing.Size(106, 26);
            this.lblZip.TabIndex = 6;
            this.lblZip.Text = "Zip Code:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhone.Location = new System.Drawing.Point(102, 221);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(81, 26);
            this.lblPhone.TabIndex = 7;
            this.lblPhone.Text = "Phone:";
            // 
            // txtZip
            // 
            this.txtZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtZip.Location = new System.Drawing.Point(189, 175);
            this.txtZip.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(534, 32);
            this.txtZip.TabIndex = 8;
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(189, 218);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(534, 32);
            this.txtPhone.TabIndex = 9;
            // 
            // btnSavePersonal
            // 
            this.btnSavePersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSavePersonal.Location = new System.Drawing.Point(461, 260);
            this.btnSavePersonal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSavePersonal.Name = "btnSavePersonal";
            this.btnSavePersonal.Size = new System.Drawing.Size(262, 64);
            this.btnSavePersonal.TabIndex = 10;
            this.btnSavePersonal.Text = "Save";
            this.btnSavePersonal.UseVisualStyleBackColor = true;
            this.btnSavePersonal.Click += new System.EventHandler(this.btnSavePersonal_Click);
            // 
            // btnClearPersonal
            // 
            this.btnClearPersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearPersonal.Location = new System.Drawing.Point(189, 260);
            this.btnClearPersonal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClearPersonal.Name = "btnClearPersonal";
            this.btnClearPersonal.Size = new System.Drawing.Size(262, 64);
            this.btnClearPersonal.TabIndex = 11;
            this.btnClearPersonal.Text = "Clear";
            this.btnClearPersonal.UseVisualStyleBackColor = true;
            this.btnClearPersonal.Click += new System.EventHandler(this.btnClearPersonal_Click_1);
            // 
            // chkAddress
            // 
            this.chkAddress.AutoSize = true;
            this.chkAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddress.Location = new System.Drawing.Point(366, 26);
            this.chkAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkAddress.Name = "chkAddress";
            this.chkAddress.Size = new System.Drawing.Size(291, 30);
            this.chkAddress.TabIndex = 12;
            this.chkAddress.Text = "Different mailing address?";
            this.chkAddress.UseVisualStyleBackColor = true;
            this.chkAddress.Visible = false;
            this.chkAddress.CheckedChanged += new System.EventHandler(this.chkAddress_CheckedChanged);
            // 
            // txtBillingAddress
            // 
            this.txtBillingAddress.Enabled = false;
            this.txtBillingAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillingAddress.Location = new System.Drawing.Point(109, 69);
            this.txtBillingAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBillingAddress.Name = "txtBillingAddress";
            this.txtBillingAddress.Size = new System.Drawing.Size(534, 32);
            this.txtBillingAddress.TabIndex = 15;
            this.txtBillingAddress.Visible = false;
            this.txtBillingAddress.Leave += new System.EventHandler(this.txtBillingAddress_Leave);
            // 
            // txtBillingCity
            // 
            this.txtBillingCity.Enabled = false;
            this.txtBillingCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillingCity.Location = new System.Drawing.Point(109, 111);
            this.txtBillingCity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBillingCity.Name = "txtBillingCity";
            this.txtBillingCity.Size = new System.Drawing.Size(534, 32);
            this.txtBillingCity.TabIndex = 16;
            this.txtBillingCity.Visible = false;
            this.txtBillingCity.Leave += new System.EventHandler(this.txtBillingCity_Leave);
            // 
            // txtBillingZip
            // 
            this.txtBillingZip.Enabled = false;
            this.txtBillingZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillingZip.Location = new System.Drawing.Point(109, 154);
            this.txtBillingZip.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBillingZip.Name = "txtBillingZip";
            this.txtBillingZip.Size = new System.Drawing.Size(534, 32);
            this.txtBillingZip.TabIndex = 17;
            this.txtBillingZip.Visible = false;
            // 
            // lblBillingAddress
            // 
            this.lblBillingAddress.AutoSize = true;
            this.lblBillingAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillingAddress.Location = new System.Drawing.Point(7, 72);
            this.lblBillingAddress.Name = "lblBillingAddress";
            this.lblBillingAddress.Size = new System.Drawing.Size(98, 26);
            this.lblBillingAddress.TabIndex = 18;
            this.lblBillingAddress.Text = "Address:";
            this.lblBillingAddress.Visible = false;
            // 
            // lblBillingCity
            // 
            this.lblBillingCity.AutoSize = true;
            this.lblBillingCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillingCity.Location = new System.Drawing.Point(52, 115);
            this.lblBillingCity.Name = "lblBillingCity";
            this.lblBillingCity.Size = new System.Drawing.Size(56, 26);
            this.lblBillingCity.TabIndex = 19;
            this.lblBillingCity.Text = "City:";
            this.lblBillingCity.Visible = false;
            // 
            // lblBillingZip
            // 
            this.lblBillingZip.AutoSize = true;
            this.lblBillingZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBillingZip.Location = new System.Drawing.Point(-2, 158);
            this.lblBillingZip.Name = "lblBillingZip";
            this.lblBillingZip.Size = new System.Drawing.Size(106, 26);
            this.lblBillingZip.TabIndex = 20;
            this.lblBillingZip.Text = "Zip Code:";
            this.lblBillingZip.Visible = false;
            // 
            // grpPersonalInfo
            // 
            this.grpPersonalInfo.Controls.Add(this.txtName);
            this.grpPersonalInfo.Controls.Add(this.lblName);
            this.grpPersonalInfo.Controls.Add(this.txtAddress);
            this.grpPersonalInfo.Controls.Add(this.lblAddress);
            this.grpPersonalInfo.Controls.Add(this.txtCity);
            this.grpPersonalInfo.Controls.Add(this.lblCity);
            this.grpPersonalInfo.Controls.Add(this.txtZip);
            this.grpPersonalInfo.Controls.Add(this.lblZip);
            this.grpPersonalInfo.Controls.Add(this.btnClearPersonal);
            this.grpPersonalInfo.Controls.Add(this.txtPhone);
            this.grpPersonalInfo.Controls.Add(this.btnSavePersonal);
            this.grpPersonalInfo.Controls.Add(this.lblPhone);
            this.grpPersonalInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpPersonalInfo.Location = new System.Drawing.Point(17, 19);
            this.grpPersonalInfo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpPersonalInfo.Name = "grpPersonalInfo";
            this.grpPersonalInfo.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpPersonalInfo.Size = new System.Drawing.Size(742, 342);
            this.grpPersonalInfo.TabIndex = 21;
            this.grpPersonalInfo.TabStop = false;
            this.grpPersonalInfo.Text = "Customer Information";
            // 
            // grpBillingAddress
            // 
            this.grpBillingAddress.Controls.Add(this.btnBillingBack);
            this.grpBillingAddress.Controls.Add(this.btnBillingAddressClear);
            this.grpBillingAddress.Controls.Add(this.btnBillingAddressSave);
            this.grpBillingAddress.Controls.Add(this.lblBillingZip);
            this.grpBillingAddress.Controls.Add(this.lblBillingCity);
            this.grpBillingAddress.Controls.Add(this.lblBillingAddress);
            this.grpBillingAddress.Controls.Add(this.txtBillingZip);
            this.grpBillingAddress.Controls.Add(this.txtBillingCity);
            this.grpBillingAddress.Controls.Add(this.txtBillingAddress);
            this.grpBillingAddress.Controls.Add(this.chkAddress);
            this.grpBillingAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBillingAddress.Location = new System.Drawing.Point(17, 19);
            this.grpBillingAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpBillingAddress.Name = "grpBillingAddress";
            this.grpBillingAddress.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpBillingAddress.Size = new System.Drawing.Size(659, 276);
            this.grpBillingAddress.TabIndex = 22;
            this.grpBillingAddress.TabStop = false;
            this.grpBillingAddress.Text = "Billing Address";
            this.grpBillingAddress.Visible = false;
            // 
            // btnBillingBack
            // 
            this.btnBillingBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillingBack.Location = new System.Drawing.Point(7, 228);
            this.btnBillingBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBillingBack.Name = "btnBillingBack";
            this.btnBillingBack.Size = new System.Drawing.Size(91, 41);
            this.btnBillingBack.TabIndex = 12;
            this.btnBillingBack.Text = "Back";
            this.btnBillingBack.UseVisualStyleBackColor = true;
            this.btnBillingBack.Click += new System.EventHandler(this.btnBillingBack_Click);
            // 
            // btnBillingAddressClear
            // 
            this.btnBillingAddressClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillingAddressClear.Location = new System.Drawing.Point(109, 196);
            this.btnBillingAddressClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBillingAddressClear.Name = "btnBillingAddressClear";
            this.btnBillingAddressClear.Size = new System.Drawing.Size(262, 64);
            this.btnBillingAddressClear.TabIndex = 23;
            this.btnBillingAddressClear.Text = "Clear";
            this.btnBillingAddressClear.UseVisualStyleBackColor = true;
            this.btnBillingAddressClear.Click += new System.EventHandler(this.btnBillingAddressClear_Click);
            // 
            // btnBillingAddressSave
            // 
            this.btnBillingAddressSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBillingAddressSave.Location = new System.Drawing.Point(381, 196);
            this.btnBillingAddressSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBillingAddressSave.Name = "btnBillingAddressSave";
            this.btnBillingAddressSave.Size = new System.Drawing.Size(262, 64);
            this.btnBillingAddressSave.TabIndex = 23;
            this.btnBillingAddressSave.Text = "Save";
            this.btnBillingAddressSave.UseVisualStyleBackColor = true;
            this.btnBillingAddressSave.Click += new System.EventHandler(this.btnBillingAddressSave_Click);
            // 
            // grpSpecifics
            // 
            this.grpSpecifics.Controls.Add(this.btnPetBack);
            this.grpSpecifics.Controls.Add(this.cboSpecies);
            this.grpSpecifics.Controls.Add(this.txtPetName);
            this.grpSpecifics.Controls.Add(this.lblPetName);
            this.grpSpecifics.Controls.Add(this.lblPetSpecies);
            this.grpSpecifics.Controls.Add(this.btnPetClear);
            this.grpSpecifics.Controls.Add(this.btnPetSave);
            this.grpSpecifics.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSpecifics.Location = new System.Drawing.Point(17, 19);
            this.grpSpecifics.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpSpecifics.Name = "grpSpecifics";
            this.grpSpecifics.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpSpecifics.Size = new System.Drawing.Size(742, 226);
            this.grpSpecifics.TabIndex = 23;
            this.grpSpecifics.TabStop = false;
            this.grpSpecifics.Text = "Pet Information";
            this.grpSpecifics.Visible = false;
            // 
            // btnPetBack
            // 
            this.btnPetBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPetBack.Location = new System.Drawing.Point(7, 178);
            this.btnPetBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPetBack.Name = "btnPetBack";
            this.btnPetBack.Size = new System.Drawing.Size(91, 41);
            this.btnPetBack.TabIndex = 24;
            this.btnPetBack.Text = "Back";
            this.btnPetBack.UseVisualStyleBackColor = true;
            this.btnPetBack.Click += new System.EventHandler(this.btnPetBack_Click);
            // 
            // cboSpecies
            // 
            this.cboSpecies.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboSpecies.FormattingEnabled = true;
            this.cboSpecies.Items.AddRange(new object[] {
            "Cat",
            "Dog",
            "Bird",
            "Snake"});
            this.cboSpecies.Location = new System.Drawing.Point(189, 90);
            this.cboSpecies.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboSpecies.Name = "cboSpecies";
            this.cboSpecies.Size = new System.Drawing.Size(534, 34);
            this.cboSpecies.TabIndex = 24;
            // 
            // txtPetName
            // 
            this.txtPetName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPetName.Location = new System.Drawing.Point(189, 48);
            this.txtPetName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPetName.Name = "txtPetName";
            this.txtPetName.Size = new System.Drawing.Size(534, 32);
            this.txtPetName.TabIndex = 0;
            // 
            // lblPetName
            // 
            this.lblPetName.AutoSize = true;
            this.lblPetName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPetName.Location = new System.Drawing.Point(108, 51);
            this.lblPetName.Name = "lblPetName";
            this.lblPetName.Size = new System.Drawing.Size(77, 26);
            this.lblPetName.TabIndex = 2;
            this.lblPetName.Text = "Name:";
            // 
            // lblPetSpecies
            // 
            this.lblPetSpecies.AutoSize = true;
            this.lblPetSpecies.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPetSpecies.Location = new System.Drawing.Point(89, 94);
            this.lblPetSpecies.Name = "lblPetSpecies";
            this.lblPetSpecies.Size = new System.Drawing.Size(96, 26);
            this.lblPetSpecies.TabIndex = 3;
            this.lblPetSpecies.Text = "Species:";
            // 
            // btnPetClear
            // 
            this.btnPetClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPetClear.Location = new System.Drawing.Point(189, 135);
            this.btnPetClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPetClear.Name = "btnPetClear";
            this.btnPetClear.Size = new System.Drawing.Size(262, 64);
            this.btnPetClear.TabIndex = 11;
            this.btnPetClear.Text = "Clear";
            this.btnPetClear.UseVisualStyleBackColor = true;
            this.btnPetClear.Click += new System.EventHandler(this.btnPetClear_Click);
            // 
            // btnPetSave
            // 
            this.btnPetSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPetSave.Location = new System.Drawing.Point(461, 135);
            this.btnPetSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPetSave.Name = "btnPetSave";
            this.btnPetSave.Size = new System.Drawing.Size(262, 64);
            this.btnPetSave.TabIndex = 10;
            this.btnPetSave.Text = "Save";
            this.btnPetSave.UseVisualStyleBackColor = true;
            this.btnPetSave.Click += new System.EventHandler(this.btnPetSave_Click);
            // 
            // grpService
            // 
            this.grpService.Controls.Add(this.lblServiceSubtotal);
            this.grpService.Controls.Add(this.txtSubtotal);
            this.grpService.Controls.Add(this.btnServiceSave);
            this.grpService.Controls.Add(this.lstServices);
            this.grpService.Controls.Add(this.cboService);
            this.grpService.Controls.Add(this.picSnake);
            this.grpService.Controls.Add(this.picBird);
            this.grpService.Controls.Add(this.picCat);
            this.grpService.Controls.Add(this.picDog);
            this.grpService.Controls.Add(this.btnServiceBack);
            this.grpService.Controls.Add(this.txtServiceName);
            this.grpService.Controls.Add(this.btnServiceClear);
            this.grpService.Controls.Add(this.btnAddService);
            this.grpService.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpService.Location = new System.Drawing.Point(17, 19);
            this.grpService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpService.Name = "grpService";
            this.grpService.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpService.Size = new System.Drawing.Size(792, 342);
            this.grpService.TabIndex = 24;
            this.grpService.TabStop = false;
            this.grpService.Text = "Service";
            this.grpService.Visible = false;
            // 
            // lblServiceSubtotal
            // 
            this.lblServiceSubtotal.AutoSize = true;
            this.lblServiceSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceSubtotal.Location = new System.Drawing.Point(529, 231);
            this.lblServiceSubtotal.Name = "lblServiceSubtotal";
            this.lblServiceSubtotal.Size = new System.Drawing.Size(98, 26);
            this.lblServiceSubtotal.TabIndex = 33;
            this.lblServiceSubtotal.Text = "Subtotal:";
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubtotal.Location = new System.Drawing.Point(628, 228);
            this.txtSubtotal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.ReadOnly = true;
            this.txtSubtotal.Size = new System.Drawing.Size(157, 32);
            this.txtSubtotal.TabIndex = 32;
            this.txtSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnServiceSave
            // 
            this.btnServiceSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceSave.Location = new System.Drawing.Point(453, 270);
            this.btnServiceSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnServiceSave.Name = "btnServiceSave";
            this.btnServiceSave.Size = new System.Drawing.Size(332, 64);
            this.btnServiceSave.TabIndex = 31;
            this.btnServiceSave.Text = "Make An Appointment";
            this.btnServiceSave.UseVisualStyleBackColor = true;
            this.btnServiceSave.Click += new System.EventHandler(this.btnServiceSave_Click);
            // 
            // lstServices
            // 
            this.lstServices.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstServices.FormattingEnabled = true;
            this.lstServices.ItemHeight = 26;
            this.lstServices.Location = new System.Drawing.Point(453, 50);
            this.lstServices.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lstServices.Name = "lstServices";
            this.lstServices.Size = new System.Drawing.Size(331, 160);
            this.lstServices.TabIndex = 30;
            // 
            // cboService
            // 
            this.cboService.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboService.FormattingEnabled = true;
            this.cboService.Items.AddRange(new object[] {
            "Check-up/Maintenance",
            "Medical attention",
            "Pre-operative",
            "Post-operative",
            "Dental cleaning",
            "Grooming"});
            this.cboService.Location = new System.Drawing.Point(192, 50);
            this.cboService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboService.Name = "cboService";
            this.cboService.Size = new System.Drawing.Size(222, 34);
            this.cboService.TabIndex = 29;
            // 
            // picSnake
            // 
            this.picSnake.Image = ((System.Drawing.Image)(resources.GetObject("picSnake.Image")));
            this.picSnake.Location = new System.Drawing.Point(9, 50);
            this.picSnake.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picSnake.Name = "picSnake";
            this.picSnake.Size = new System.Drawing.Size(158, 121);
            this.picSnake.TabIndex = 28;
            this.picSnake.TabStop = false;
            this.picSnake.Visible = false;
            // 
            // picBird
            // 
            this.picBird.Image = ((System.Drawing.Image)(resources.GetObject("picBird.Image")));
            this.picBird.Location = new System.Drawing.Point(9, 50);
            this.picBird.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picBird.Name = "picBird";
            this.picBird.Size = new System.Drawing.Size(158, 121);
            this.picBird.TabIndex = 27;
            this.picBird.TabStop = false;
            this.picBird.Visible = false;
            // 
            // picCat
            // 
            this.picCat.Image = ((System.Drawing.Image)(resources.GetObject("picCat.Image")));
            this.picCat.Location = new System.Drawing.Point(7, 50);
            this.picCat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picCat.Name = "picCat";
            this.picCat.Size = new System.Drawing.Size(158, 121);
            this.picCat.TabIndex = 26;
            this.picCat.TabStop = false;
            this.picCat.Visible = false;
            // 
            // picDog
            // 
            this.picDog.Image = ((System.Drawing.Image)(resources.GetObject("picDog.Image")));
            this.picDog.Location = new System.Drawing.Point(7, 50);
            this.picDog.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picDog.Name = "picDog";
            this.picDog.Size = new System.Drawing.Size(158, 121);
            this.picDog.TabIndex = 25;
            this.picDog.TabStop = false;
            this.picDog.Visible = false;
            // 
            // btnServiceBack
            // 
            this.btnServiceBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceBack.Location = new System.Drawing.Point(7, 292);
            this.btnServiceBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnServiceBack.Name = "btnServiceBack";
            this.btnServiceBack.Size = new System.Drawing.Size(91, 41);
            this.btnServiceBack.TabIndex = 24;
            this.btnServiceBack.Text = "Back";
            this.btnServiceBack.UseVisualStyleBackColor = true;
            this.btnServiceBack.Click += new System.EventHandler(this.btnServiceBack_Click);
            // 
            // txtServiceName
            // 
            this.txtServiceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceName.Location = new System.Drawing.Point(7, 179);
            this.txtServiceName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtServiceName.Name = "txtServiceName";
            this.txtServiceName.Size = new System.Drawing.Size(157, 32);
            this.txtServiceName.TabIndex = 0;
            this.txtServiceName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnServiceClear
            // 
            this.btnServiceClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceClear.Location = new System.Drawing.Point(115, 270);
            this.btnServiceClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnServiceClear.Name = "btnServiceClear";
            this.btnServiceClear.Size = new System.Drawing.Size(332, 64);
            this.btnServiceClear.TabIndex = 11;
            this.btnServiceClear.Text = "Clear";
            this.btnServiceClear.UseVisualStyleBackColor = true;
            this.btnServiceClear.Click += new System.EventHandler(this.btnServiceClear_Click);
            // 
            // btnAddService
            // 
            this.btnAddService.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddService.Location = new System.Drawing.Point(192, 108);
            this.btnAddService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAddService.Name = "btnAddService";
            this.btnAddService.Size = new System.Drawing.Size(223, 64);
            this.btnAddService.TabIndex = 10;
            this.btnAddService.Text = "Add";
            this.btnAddService.UseVisualStyleBackColor = true;
            this.btnAddService.Click += new System.EventHandler(this.btnAddService_Click);
            // 
            // grpAppointment
            // 
            this.grpAppointment.Controls.Add(this.btnInventory);
            this.grpAppointment.Controls.Add(this.mocDate);
            this.grpAppointment.Controls.Add(this.txtComments);
            this.grpAppointment.Controls.Add(this.lblComments);
            this.grpAppointment.Controls.Add(this.lblTime);
            this.grpAppointment.Controls.Add(this.cboTime);
            this.grpAppointment.Controls.Add(this.lblEnding);
            this.grpAppointment.Controls.Add(this.btnAppointmentBack2);
            this.grpAppointment.Controls.Add(this.btnCreateAnother);
            this.grpAppointment.Controls.Add(this.btnAppointmentRestart);
            this.grpAppointment.Controls.Add(this.lblTotalCost);
            this.grpAppointment.Controls.Add(this.txtTotalCost);
            this.grpAppointment.Controls.Add(this.txtSalesTax);
            this.grpAppointment.Controls.Add(this.btnAppointmentBack);
            this.grpAppointment.Controls.Add(this.txtAppointmentCost);
            this.grpAppointment.Controls.Add(this.lblCost);
            this.grpAppointment.Controls.Add(this.lblSalesTax);
            this.grpAppointment.Controls.Add(this.btnConfirm);
            this.grpAppointment.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAppointment.Location = new System.Drawing.Point(17, 19);
            this.grpAppointment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpAppointment.Name = "grpAppointment";
            this.grpAppointment.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.grpAppointment.Size = new System.Drawing.Size(790, 339);
            this.grpAppointment.TabIndex = 25;
            this.grpAppointment.TabStop = false;
            this.grpAppointment.Text = "Create Appointment";
            this.grpAppointment.Visible = false;
            // 
            // mocDate
            // 
            this.mocDate.Location = new System.Drawing.Point(121, 48);
            this.mocDate.Margin = new System.Windows.Forms.Padding(10, 11, 10, 11);
            this.mocDate.MaxDate = new System.DateTime(2021, 4, 20, 0, 0, 0, 0);
            this.mocDate.MinDate = new System.DateTime(2020, 4, 10, 18, 40, 0, 0);
            this.mocDate.Name = "mocDate";
            this.mocDate.ShowTodayCircle = false;
            this.mocDate.TabIndex = 28;
            // 
            // txtComments
            // 
            this.txtComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComments.Location = new System.Drawing.Point(133, 220);
            this.txtComments.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtComments.Name = "txtComments";
            this.txtComments.Size = new System.Drawing.Size(289, 32);
            this.txtComments.TabIndex = 35;
            this.txtComments.Text = "\r\n";
            this.txtComments.Visible = false;
            // 
            // lblComments
            // 
            this.lblComments.AutoSize = true;
            this.lblComments.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComments.Location = new System.Drawing.Point(7, 224);
            this.lblComments.Name = "lblComments";
            this.lblComments.Size = new System.Drawing.Size(125, 26);
            this.lblComments.TabIndex = 34;
            this.lblComments.Text = "Comments:";
            this.lblComments.Visible = false;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(7, 72);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(66, 26);
            this.lblTime.TabIndex = 33;
            this.lblTime.Text = "Time:";
            // 
            // cboTime
            // 
            this.cboTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTime.FormattingEnabled = true;
            this.cboTime.Items.AddRange(new object[] {
            "9:00",
            "10:00",
            "11:00",
            "1:00",
            "2:00"});
            this.cboTime.Location = new System.Drawing.Point(7, 106);
            this.cboTime.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboTime.Name = "cboTime";
            this.cboTime.Size = new System.Drawing.Size(100, 34);
            this.cboTime.TabIndex = 32;
            // 
            // lblEnding
            // 
            this.lblEnding.AutoSize = true;
            this.lblEnding.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnding.ForeColor = System.Drawing.Color.CadetBlue;
            this.lblEnding.Location = new System.Drawing.Point(44, 72);
            this.lblEnding.Name = "lblEnding";
            this.lblEnding.Size = new System.Drawing.Size(323, 80);
            this.lblEnding.TabIndex = 31;
            this.lblEnding.Text = "Thank you for \r\nusing AllPets Clinic";
            this.lblEnding.Visible = false;
            // 
            // btnAppointmentBack2
            // 
            this.btnAppointmentBack2.Enabled = false;
            this.btnAppointmentBack2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointmentBack2.Location = new System.Drawing.Point(7, 290);
            this.btnAppointmentBack2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointmentBack2.Name = "btnAppointmentBack2";
            this.btnAppointmentBack2.Size = new System.Drawing.Size(91, 41);
            this.btnAppointmentBack2.TabIndex = 30;
            this.btnAppointmentBack2.Text = "Back";
            this.btnAppointmentBack2.UseVisualStyleBackColor = true;
            this.btnAppointmentBack2.Visible = false;
            this.btnAppointmentBack2.Click += new System.EventHandler(this.btnAppointmentBack2_Click);
            // 
            // btnCreateAnother
            // 
            this.btnCreateAnother.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateAnother.ForeColor = System.Drawing.Color.CadetBlue;
            this.btnCreateAnother.Location = new System.Drawing.Point(474, 146);
            this.btnCreateAnother.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCreateAnother.Name = "btnCreateAnother";
            this.btnCreateAnother.Size = new System.Drawing.Size(309, 90);
            this.btnCreateAnother.TabIndex = 28;
            this.btnCreateAnother.Text = "Create Another \r\nAppointment?";
            this.btnCreateAnother.UseVisualStyleBackColor = true;
            this.btnCreateAnother.Visible = false;
            this.btnCreateAnother.Click += new System.EventHandler(this.btnCreateAnother_Click);
            // 
            // btnAppointmentRestart
            // 
            this.btnAppointmentRestart.Enabled = false;
            this.btnAppointmentRestart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointmentRestart.ForeColor = System.Drawing.Color.CadetBlue;
            this.btnAppointmentRestart.Location = new System.Drawing.Point(474, 54);
            this.btnAppointmentRestart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointmentRestart.Name = "btnAppointmentRestart";
            this.btnAppointmentRestart.Size = new System.Drawing.Size(309, 90);
            this.btnAppointmentRestart.TabIndex = 29;
            this.btnAppointmentRestart.Text = "Start Over";
            this.btnAppointmentRestart.UseVisualStyleBackColor = true;
            this.btnAppointmentRestart.Visible = false;
            this.btnAppointmentRestart.Click += new System.EventHandler(this.btnAppointmentRestart_Click);
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.Location = new System.Drawing.Point(546, 201);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(116, 26);
            this.lblTotalCost.TabIndex = 27;
            this.lblTotalCost.Text = "Total Cost:";
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCost.Location = new System.Drawing.Point(663, 198);
            this.txtTotalCost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.ReadOnly = true;
            this.txtTotalCost.Size = new System.Drawing.Size(120, 32);
            this.txtTotalCost.TabIndex = 26;
            // 
            // txtSalesTax
            // 
            this.txtSalesTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalesTax.Location = new System.Drawing.Point(663, 155);
            this.txtSalesTax.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSalesTax.Name = "txtSalesTax";
            this.txtSalesTax.ReadOnly = true;
            this.txtSalesTax.Size = new System.Drawing.Size(120, 32);
            this.txtSalesTax.TabIndex = 25;
            // 
            // btnAppointmentBack
            // 
            this.btnAppointmentBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAppointmentBack.Location = new System.Drawing.Point(7, 290);
            this.btnAppointmentBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnAppointmentBack.Name = "btnAppointmentBack";
            this.btnAppointmentBack.Size = new System.Drawing.Size(91, 41);
            this.btnAppointmentBack.TabIndex = 24;
            this.btnAppointmentBack.Text = "Back";
            this.btnAppointmentBack.UseVisualStyleBackColor = true;
            this.btnAppointmentBack.Click += new System.EventHandler(this.btnAppointmentBack_Click);
            // 
            // txtAppointmentCost
            // 
            this.txtAppointmentCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAppointmentCost.Location = new System.Drawing.Point(663, 112);
            this.txtAppointmentCost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAppointmentCost.Name = "txtAppointmentCost";
            this.txtAppointmentCost.ReadOnly = true;
            this.txtAppointmentCost.Size = new System.Drawing.Size(120, 32);
            this.txtAppointmentCost.TabIndex = 0;
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.Location = new System.Drawing.Point(484, 116);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(182, 26);
            this.lblCost.TabIndex = 2;
            this.lblCost.Text = "Cost Of Services:";
            // 
            // lblSalesTax
            // 
            this.lblSalesTax.AutoSize = true;
            this.lblSalesTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalesTax.Location = new System.Drawing.Point(546, 159);
            this.lblSalesTax.Name = "lblSalesTax";
            this.lblSalesTax.Size = new System.Drawing.Size(114, 26);
            this.lblSalesTax.TabIndex = 3;
            this.lblSalesTax.Text = "Sales Tax:";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Location = new System.Drawing.Point(522, 268);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(261, 64);
            this.btnConfirm.TabIndex = 10;
            this.btnConfirm.Text = "Confirm Appointment";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblProgrammers
            // 
            this.lblProgrammers.AutoSize = true;
            this.lblProgrammers.Font = new System.Drawing.Font("Mongolian Baiti", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgrammers.Location = new System.Drawing.Point(9, 378);
            this.lblProgrammers.Name = "lblProgrammers";
            this.lblProgrammers.Size = new System.Drawing.Size(267, 39);
            this.lblProgrammers.TabIndex = 26;
            this.lblProgrammers.Text = "ZD, SA, CT, PL";
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(790, 384);
            this.btnExit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(84, 38);
            this.btnExit.TabIndex = 27;
            this.btnExit.Text = "Close";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnInventory
            // 
            this.btnInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventory.ForeColor = System.Drawing.Color.CadetBlue;
            this.btnInventory.Location = new System.Drawing.Point(474, 238);
            this.btnInventory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(309, 90);
            this.btnInventory.TabIndex = 36;
            this.btnInventory.Text = "See Inventory";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Visible = false;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // frmAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(888, 434);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblProgrammers);
            this.Controls.Add(this.grpAppointment);
            this.Controls.Add(this.grpSpecifics);
            this.Controls.Add(this.grpBillingAddress);
            this.Controls.Add(this.grpService);
            this.Controls.Add(this.grpPersonalInfo);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmAppointment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AllPets Clinic Appointments";
            this.grpPersonalInfo.ResumeLayout(false);
            this.grpPersonalInfo.PerformLayout();
            this.grpBillingAddress.ResumeLayout(false);
            this.grpBillingAddress.PerformLayout();
            this.grpSpecifics.ResumeLayout(false);
            this.grpSpecifics.PerformLayout();
            this.grpService.ResumeLayout(false);
            this.grpService.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSnake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDog)).EndInit();
            this.grpAppointment.ResumeLayout(false);
            this.grpAppointment.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblZip;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Button btnSavePersonal;
        private System.Windows.Forms.Button btnClearPersonal;
        private System.Windows.Forms.CheckBox chkAddress;
        private System.Windows.Forms.TextBox txtBillingAddress;
        private System.Windows.Forms.TextBox txtBillingCity;
        private System.Windows.Forms.TextBox txtBillingZip;
        private System.Windows.Forms.Label lblBillingAddress;
        private System.Windows.Forms.Label lblBillingCity;
        private System.Windows.Forms.Label lblBillingZip;
        private System.Windows.Forms.GroupBox grpPersonalInfo;
        private System.Windows.Forms.GroupBox grpBillingAddress;
        private System.Windows.Forms.Button btnBillingAddressClear;
        private System.Windows.Forms.Button btnBillingAddressSave;
        private System.Windows.Forms.GroupBox grpSpecifics;
        private System.Windows.Forms.TextBox txtPetName;
        private System.Windows.Forms.Label lblPetName;
        private System.Windows.Forms.Label lblPetSpecies;
        private System.Windows.Forms.Button btnPetClear;
        private System.Windows.Forms.Button btnPetSave;
        private System.Windows.Forms.ComboBox cboSpecies;
        private System.Windows.Forms.Button btnBillingBack;
        private System.Windows.Forms.Button btnPetBack;
        private System.Windows.Forms.GroupBox grpService;
        private System.Windows.Forms.Button btnServiceBack;
        private System.Windows.Forms.TextBox txtServiceName;
        private System.Windows.Forms.Button btnServiceClear;
        private System.Windows.Forms.Button btnAddService;
        private System.Windows.Forms.PictureBox picCat;
        private System.Windows.Forms.PictureBox picDog;
        private System.Windows.Forms.PictureBox picSnake;
        private System.Windows.Forms.PictureBox picBird;
        private System.Windows.Forms.ComboBox cboService;
        private System.Windows.Forms.ListBox lstServices;
        private System.Windows.Forms.Button btnServiceSave;
        private System.Windows.Forms.GroupBox grpAppointment;
        private System.Windows.Forms.Button btnAppointmentBack;
        private System.Windows.Forms.TextBox txtAppointmentCost;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblSalesTax;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.TextBox txtSalesTax;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.TextBox txtTotalCost;
        private System.Windows.Forms.TextBox txtSubtotal;
        private System.Windows.Forms.Button btnAppointmentRestart;
        private System.Windows.Forms.Button btnCreateAnother;
        private System.Windows.Forms.Label lblServiceSubtotal;
        private System.Windows.Forms.Button btnAppointmentBack2;
        private System.Windows.Forms.Label lblEnding;
        private System.Windows.Forms.Label lblProgrammers;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.ComboBox cboTime;
        private System.Windows.Forms.Label lblComments;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.MonthCalendar mocDate;
        private System.Windows.Forms.Button btnInventory;
    }
}

